requirejs.config({
    baseUrl: 'https://www.pretagov.co.uk',
    paths: {
    "less": "++plone++static/components/less/dist/less", 
    "text": "++plone++static/components/requirejs-text/text", 
    "mockup-patterns-recurrence": "++resource++mockup/recurrence/pattern", 
    "mockup-patterns-tinymce": "++resource++mockup/tinymce/pattern", 
    "mockup-parser": "++plone++static/components/mockup-core/js/parser", 
    "mockup-router": "++resource++mockupjs/router", 
    "tinymce-spellchecker": "++plone++static/components/tinymce-builded/js/tinymce/plugins/spellchecker/plugin", 
    "jquery.event.drop": "++resource++mockuplib/jquery.event.drop", 
    "tinymce-autosave": "++plone++static/components/tinymce-builded/js/tinymce/plugins/autosave/plugin", 
    "tinymce-charmap": "++plone++static/components/tinymce-builded/js/tinymce/plugins/charmap/plugin", 
    "tinymce-save": "++plone++static/components/tinymce-builded/js/tinymce/plugins/save/plugin", 
    "tinymce-fullscreen": "++plone++static/components/tinymce-builded/js/tinymce/plugins/fullscreen/plugin", 
    "tinymce-noneditable": "++plone++static/components/tinymce-builded/js/tinymce/plugins/noneditable/plugin", 
    "ace-mode-javascript": "++plone++static/components/ace-builds/src/mode-javascript", 
    "tinymce-advlist": "++plone++static/components/tinymce-builded/js/tinymce/plugins/advlist/plugin", 
    "tinymce-preview": "++plone++static/components/tinymce-builded/js/tinymce/plugins/preview/plugin", 
    "mockup-patterns-tree": "++resource++mockup/tree/pattern", 
    "tinymce-pagebreak": "++plone++static/components/tinymce-builded/js/tinymce/plugins/pagebreak/plugin", 
    "jquery.event.drag": "++resource++mockuplib/jquery.event.drag", 
    "mockup-patterns-formautofocus": "++resource++mockup/formautofocus/pattern", 
    "mockup-i18n": "++resource++mockupjs/i18n", 
    "underscore": "++plone++static/components/underscore/underscore", 
    "pat-logger": "++plone++static/components/patternslib/src/core/logger", 
    "ace-mode-text": "++plone++static/components/ace-builds/src/mode-text", 
    "backbone.paginator": "++plone++static/components/backbone.paginator/lib/backbone.paginator", 
    "jqtree": "++plone++static/components/jqtree/tree.jquery", 
    "tinymce-textcolor": "++plone++static/components/tinymce-builded/js/tinymce/plugins/textcolor/plugin", 
    "picker.time": "++plone++static/components/pickadate/lib/picker.time", 
    "tinymce-fullpage": "++plone++static/components/tinymce-builded/js/tinymce/plugins/fullpage/plugin", 
    "tinymce-compat3x": "++plone++static/components/tinymce-builded/js/tinymce/plugins/compat3x/plugin", 
    "pat-jquery-ext": "++plone++static/components/patternslib/src/core/jquery-ext", 
    "mockup-patterns-thememapper": "++resource++mockup/thememapper/pattern", 
    "mockup-patterns-filemanager-url": "++resource++mockup/filemanager", 
    "bootstrap-transition": "++plone++static/components/bootstrap/js/transition", 
    "mockup-patterns-tinymce-url": "++resource++mockup/tinymce", 
    "mosaic-url": "++plone++mosaic/js", 
    "tinymce-visualchars": "++plone++static/components/tinymce-builded/js/tinymce/plugins/visualchars/plugin", 
    "expect": "++plone++static/components/expect/index", 
    "tinymce-anchor": "++plone++static/components/tinymce-builded/js/tinymce/plugins/anchor/plugin", 
    "mockup-patterns-filemanager": "++resource++mockup/filemanager/pattern", 
    "mockup-patterns-backdrop": "++resource++mockup/backdrop/pattern", 
    "mockup-patterns-cookietrigger": "++resource++mockup/cookietrigger/pattern", 
    "pfgquickedit": "++plone++pfgquickedit/quickedit", 
    "mockup-patterns-modal": "++resource++mockup/modal/pattern", 
    "jquery.cookie": "++plone++static/components/jquery.cookie/jquery.cookie", 
    "tinymce-wordcount": "++plone++static/components/tinymce-builded/js/tinymce/plugins/wordcount/plugin", 
    "mockup-utils": "++resource++mockupjs/utils", 
    "mockup-registry": "++plone++static/components/mockup-core/js/registry", 
    "plone-patterns-portletmanager": "++resource++manage-portlets", 
    "tinymce-modern-theme": "++plone++static/components/tinymce-builded/js/tinymce/themes/modern/theme", 
    "tinymce-paste": "++plone++static/components/tinymce-builded/js/tinymce/plugins/paste/plugin", 
    "resource-plone-app-discussion-javascripts-comments": "++resource++plone.app.discussion.javascripts/comments", 
    "mockup-patterns-upload-url": "++resource++mockup/upload", 
    "tinymce-bbcode": "++plone++static/components/tinymce-builded/js/tinymce/plugins/bbcode/plugin", 
    "mockup-patterns-querystring": "++resource++mockup/querystring/pattern", 
    "logging": "++plone++static/components/logging/src/logging", 
    "ace": "++plone++static/components/ace-builds/src/ace", 
    "mockup-patterns-thememapper-url": "++resource++mockup/thememapper", 
    "tinymce-autolink": "++plone++static/components/tinymce-builded/js/tinymce/plugins/autolink/plugin", 
    "mockup-patterns-formunloadalert": "++resource++mockup/formunloadalert/pattern", 
    "picker": "++plone++static/components/pickadate/lib/picker", 
    "mockup-patterns-structure-url": "++resource++mockup/structure", 
    "tinymce-image": "++plone++static/components/tinymce-builded/js/tinymce/plugins/image/plugin", 
    "marked": "++plone++static/components/marked/lib/marked", 
    "ace-mode-css": "++plone++static/components/ace-builds/src/mode-css", 
    "pat-registry": "++plone++static/components/patternslib/src/core/registry", 
    "plone": "++resource++plone", 
    "resource-plone-app-jquerytools-js": "++plone++static/components/jquery.recurrenceinput.js/lib/jquery.tools.overlay", 
    "mockup-patterns-select2": "++resource++mockup/select2/pattern", 
    "mockup-patterns-structure": "++resource++mockup/structure/pattern", 
    "tinymce-autoresize": "++plone++static/components/tinymce-builded/js/tinymce/plugins/autoresize/plugin", 
    "jquery.recurrenceinput": "++plone++static/components/jquery.recurrenceinput.js/src/jquery.recurrenceinput", 
    "jquery.form": "++plone++static/components/jquery-form/jquery.form", 
    "pat-utils": "++plone++static/components/patternslib/src/core/utils", 
    "mockup-patterns-sortable": "++resource++mockup/sortable/pattern", 
    "tinymce-template": "++plone++static/components/tinymce-builded/js/tinymce/plugins/template/plugin", 
    "translate": "++resource++mockupjs/i18n-wrapper", 
    "bootstrap-dropdown": "++plone++static/components/bootstrap/js/dropdown", 
    "mockup-patterns-contentloader": "++resource++mockup/contentloader/pattern", 
    "rjs": "++plone++static/components/r.js/dist/r", 
    "tinymce-lists": "++plone++static/components/tinymce-builded/js/tinymce/plugins/lists/plugin", 
    "bootstrap-alert": "++plone++static/components/bootstrap/js/alert", 
    "tinymce-textpattern": "++plone++static/components/tinymce-builded/js/tinymce/plugins/textpattern/plugin", 
    "tinymce-emoticons": "++plone++static/components/tinymce-builded/js/tinymce/plugins/emoticons/plugin", 
    "resourceregistry": "++plone++static/resourceregistry", 
    "tinymce-table": "++plone++static/components/tinymce-builded/js/tinymce/plugins/table/plugin", 
    "jquery": "++plone++static/components/jquery/dist/jquery.min", 
    "mockup-ui-url": "++resource++mockupjs/ui", 
    "tinymce-tabfocus": "++plone++static/components/tinymce-builded/js/tinymce/plugins/tabfocus/plugin", 
    "resource-plone-app-event-event-js": "++resource++plone.app.event/event", 
    "tinymce-print": "++plone++static/components/tinymce-builded/js/tinymce/plugins/print/plugin", 
    "mockup-patterns-preventdoublesubmit": "++resource++mockup/preventdoublesubmit/pattern", 
    "tinymce-link": "++plone++static/components/tinymce-builded/js/tinymce/plugins/link/plugin", 
    "pat-compat": "++plone++static/components/patternslib/src/core/compat", 
    "tinymce-hr": "++plone++static/components/tinymce-builded/js/tinymce/plugins/hr/plugin", 
    "select2": "++plone++static/components/select2/select2", 
    "tinymce-media": "++plone++static/components/tinymce-builded/js/tinymce/plugins/media/plugin", 
    "mockup-patterns-texteditor": "++resource++mockup/texteditor/pattern", 
    "mockup-patterns-tooltip": "++resource++mockup/tooltip/pattern", 
    "resource-plone-app-jquerytools-dateinput-js": "++plone++static/components/jquery.recurrenceinput.js/lib/jquery.tools.dateinput", 
    "plone-logged-in": "++resource++plone-logged-in", 
    "mockup-patterns-pickadate": "++resource++mockup/pickadate/pattern", 
    "JSXTransformer": "++plone++static/components/react/JSXTransformer", 
    "tinymce-contextmenu": "++plone++static/components/tinymce-builded/js/tinymce/plugins/contextmenu/plugin", 
    "ace-theme-monokai": "++plone++static/components/ace-builds/src/theme-monokai", 
    "mockup-patterns-toggle": "++resource++mockup/toggle/pattern", 
    "tinymce-directionality": "++plone++static/components/tinymce-builded/js/tinymce/plugins/directionality/plugin", 
    "mockup-patterns-markspeciallinks": "++resource++mockup/markspeciallinks/pattern", 
    "tinymce-legacyoutput": "++plone++static/components/tinymce-builded/js/tinymce/plugins/legacyoutput/plugin", 
    "pat-base": "++plone++static/components/patternslib/src/core/base", 
    "plone-patterns-toolbar": "++plone++static/patterns/toolbar/src/toolbar", 
    "mockup-patterns-inlinevalidation": "++resource++mockup/inlinevalidation/pattern", 
    "thememapper": "++resource++plone.app.theming/thememapper", 
    "tinymce": "++plone++static/components/tinymce-builded/js/tinymce/tinymce", 
    "mosaic-base-url": "++plone++mosaic/js", 
    "tinymce-visualblocks": "++plone++static/components/tinymce-builded/js/tinymce/plugins/visualblocks/plugin", 
    "mockup-patterns-resourceregistry-url": "++resource++mockup/resourceregistry", 
    "tinymce-insertdatetime": "++plone++static/components/tinymce-builded/js/tinymce/plugins/insertdatetime/plugin", 
    "mockup-patterns-base": "++resource++mockup/base/pattern", 
    "mockup-patterns-livesearch": "++resource++mockup/livesearch/pattern", 
    "mockup-patterns-upload": "++resource++mockup/upload/pattern", 
    "picker.date": "++plone++static/components/pickadate/lib/picker.date", 
    "tinymce-searchreplace": "++plone++static/components/tinymce-builded/js/tinymce/plugins/searchreplace/plugin", 
    "mockup-patterns-autotoc": "++resource++mockup/autotoc/pattern", 
    "tinymce-importcss": "++plone++static/components/tinymce-builded/js/tinymce/plugins/importcss/plugin", 
    "backbone": "++plone++static/components/backbone/backbone", 
    "mockup-patterns-resourceregistry": "++resource++mockup/resourceregistry/pattern", 
    "react": "++plone++static/components/react/react", 
    "mockup-patterns-textareamimetypeselector": "++resource++mockup/textareamimetypeselector/pattern", 
    "moment": "++plone++static/components/moment/min/moment-with-locales.min", 
    "sinon": "++plone++static/components/sinonjs/sinon", 
    "tinymce-code": "++plone++static/components/tinymce-builded/js/tinymce/plugins/code/plugin", 
    "mosaic": "++plone++mosaic/js/mosaic.pattern", 
    "tinymce-colorpicker": "++plone++static/components/tinymce-builded/js/tinymce/plugins/colorpicker/plugin", 
    "jquery.tmpl": "++plone++static/components/jquery.recurrenceinput.js/lib/jquery.tmpl", 
    "tinymce-layer": "++plone++static/components/tinymce-builded/js/tinymce/plugins/layer/plugin", 
    "bootstrap-collapse": "++plone++static/components/bootstrap/js/collapse", 
    "jquery-highlightsearchterms": "jquery.highlightsearchterms", 
    "mockup-patterns-moment": "++resource++mockup/moment/pattern", 
    "mockup-patterns-relateditems": "++resource++mockup/relateditems/pattern", 
    "tinymce-nonbreaking": "++plone++static/components/tinymce-builded/js/tinymce/plugins/nonbreaking/plugin", 
    "layouts-editor": "++plone++mosaic/js/layouts-editor", 
    "bootstrap-tooltip": "++plone++static/components/bootstrap/js/tooltip", 
    "pat-mockup-parser": "++plone++static/components/patternslib/src/core/mockup-parser", 
    "dropzone": "++plone++static/components/dropzone/dist/dropzone-amd-module"
},
    shim: {
        "resource-plone-app-jquerytools-dateinput-js": {
            deps: ["jquery"]
        },
        "tinymce-autoresize": {
            deps: ["tinymce"]
        },
        "bootstrap-transition": {
            exports: "window.jQuery.support.transition",
            deps: ["jquery"]
        },
        "tinymce-save": {
            deps: ["tinymce"]
        },
        "bootstrap-collapse": {
            exports: "window.jQuery.fn.collapse.Constructor",
            deps: ["jquery"]
        },
        "tinymce-fullpage": {
            deps: ["tinymce"]
        },
        "tinymce-visualchars": {
            deps: ["tinymce"]
        },
        "expect": {
            exports: "window.expect"
        },
        "tinymce-spellchecker": {
            deps: ["tinymce"]
        },
        "jquery.event.drop": {
            exports: "$.drop",
            deps: ["jquery"]
        },
        "tinymce-anchor": {
            deps: ["tinymce"]
        },
        "tinymce-autosave": {
            deps: ["tinymce"]
        },
        "tinymce-contextmenu": {
            deps: ["tinymce"]
        },
        "tinymce-charmap": {
            deps: ["tinymce"]
        },
        "resource-plone-app-jquerytools-js": {
            deps: ["jquery"]
        },
        "tinymce-directionality": {
            deps: ["tinymce"]
        },
        "tinymce": {
            exports: "window.tinyMCE",
            init: function () { this.tinyMCE.DOM.events.domLoaded = true; return this.tinyMCE; }
        },
        "tinymce-image": {
            deps: ["tinymce"]
        },
        "tinymce-layer": {
            deps: ["tinymce"]
        },
        "jquery.cookie": {
            deps: ["jquery"]
        },
        "jquery.recurrenceinput": {
            deps: ["jquery", "resource-plone-app-jquerytools-js", "resource-plone-app-jquerytools-dateinput-js", "jquery.tmpl"]
        },
        "tinymce-fullscreen": {
            deps: ["tinymce"]
        },
        "tinymce-noneditable": {
            deps: ["tinymce"]
        },
        "tinymce-wordcount": {
            deps: ["tinymce"]
        },
        "tinymce-insertdatetime": {
            deps: ["tinymce"]
        },
        "tinymce-advlist": {
            deps: ["tinymce"]
        },
        "tinymce-visualblocks": {
            deps: ["tinymce"]
        },
        "tinymce-searchreplace": {
            deps: ["tinymce"]
        },
        "tinymce-template": {
            deps: ["tinymce"]
        },
        "picker.date": {
            deps: ["picker"]
        },
        "tinymce-modern-theme": {
            deps: ["tinymce"]
        },
        "bootstrap-dropdown": {
            deps: ["jquery"]
        },
        "tinymce-preview": {
            deps: ["tinymce"]
        },
        "tinymce-paste": {
            deps: ["tinymce"]
        },
        "tinymce-pagebreak": {
            deps: ["tinymce"]
        },
        "tinymce-importcss": {
            deps: ["tinymce"]
        },
        "tinymce-lists": {
            deps: ["tinymce"]
        },
        "bootstrap-alert": {
            deps: ["jquery"]
        },
        "jqtree": {
            deps: ["jquery"]
        },
        "tinymce-textpattern": {
            deps: ["tinymce"]
        },
        "backbone": {
            exports: "window.Backbone",
            deps: ["underscore", "jquery"]
        },
        "jquery.tmpl": {
            deps: ["jquery"]
        },
        "tinymce-emoticons": {
            deps: ["tinymce"]
        },
        "sinon": {
            exports: "window.sinon"
        },
        "tinymce-table": {
            deps: ["tinymce"]
        },
        "underscore": {
            exports: "window._"
        },
        "tinymce-code": {
            deps: ["tinymce"]
        },
        "tinymce-bbcode": {
            deps: ["tinymce"]
        },
        "tinymce-print": {
            deps: ["tinymce"]
        },
        "tinymce-colorpicker": {
            deps: ["tinymce"]
        },
        "jquery.event.drag": {
            deps: ["jquery"]
        },
        "backbone.paginator": {
            exports: "window.Backbone.Paginator",
            deps: ["backbone"]
        },
        "tinymce-legacyoutput": {
            deps: ["tinymce"]
        },
        "tinymce-tabfocus": {
            deps: ["tinymce"]
        },
        "tinymce-textcolor": {
            deps: ["tinymce"]
        },
        "picker.time": {
            deps: ["picker"]
        },
        "JSXTransformer": {
            exports: "window.JSXTransformer"
        },
        "tinymce-compat3x": {
            deps: ["tinymce"]
        },
        "tinymce-link": {
            deps: ["tinymce"]
        },
        "tinymce-nonbreaking": {
            deps: ["tinymce"]
        },
        "bootstrap-tooltip": {
            deps: ["jquery"]
        },
        "tinymce-hr": {
            deps: ["tinymce"]
        },
        "tinymce-autolink": {
            deps: ["tinymce"]
        },
        "tinymce-media": {
            deps: ["tinymce"]
        }
    },
    optimize: 'uglify',
    wrapShim: true
});